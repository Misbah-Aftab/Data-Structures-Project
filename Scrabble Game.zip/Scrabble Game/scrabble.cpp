#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include <random>
#include <map>
#include<iostream>
#include <functional>
#include<fstream>
#include <SFML/Audio.hpp>
#include <algorithm>

using namespace std;
bool isFirstMove = true;
const int GRID_SIZE = 15;
const int TILE_SIZE = 35;
const int SLATE_TILE_COUNT = 7;  // Number of tiles on each player's slate
const int WINDOW_WIDTH = 900;
const int WINDOW_HEIGHT = (GRID_SIZE + 2) * TILE_SIZE;  // Extra space for top and bottom slates
const sf::Color DOUBLE_LETTER_COLOR(173, 216, 230), TRIPLE_LETTER_COLOR(0, 116, 116);
const sf::Color DOUBLE_WORD_COLOR(255, 182, 193), TRIPLE_WORD_COLOR(255, 69, 0), Centre(144, 238, 144);
std::map<char, int> tileDistribution = {
    {'A', 9}, {'B', 2}, {'C', 2}, {'D', 4}, {'E', 12}, {'F', 2}, {'G', 3}, {'H', 2},
    {'I', 9}, {'J', 1}, {'K', 1}, {'L', 4}, {'M', 2}, {'N', 6}, {'O', 8}, {'P', 2},
    {'Q', 1}, {'R', 6}, {'S', 4}, {'T', 6}, {'U', 4}, {'V', 2}, {'W', 2}, {'X', 1},
    {'Y', 2}, {'Z', 1},{' ',2}
};


std::vector<char> generateTileBag() {
    std::vector<char> bag;
    for (const auto& pair : tileDistribution) {
        char letter = pair.first;
        int count = pair.second;
        bag.insert(bag.end(), count, letter);
    }
    return bag;
}
std::vector<char> drawTiles(std::vector<char>& bag, int count) {
    if (bag.empty()) {
        std::cerr << "Error: Tile bag is empty. No tiles to draw." << std::endl;
        return {};
    }

    // Ensure we do not attempt to draw more tiles than available
    count = std::min(count, static_cast<int>(bag.size()));

    // Shuffle the entire bag
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(bag.begin(), bag.end(), g);

    // Extract the last `count` tiles
    std::vector<char> drawnTiles(bag.end() - count, bag.end());
    bag.erase(bag.end() - count, bag.end());

    return drawnTiles;
}
struct TrieNode {
    std::map<char, TrieNode*> children;
    bool isEndOfWord = false;
};
class Trie {
private:
    TrieNode* root;

    // Helper function to convert a string to lowercase
    std::string toLower(const std::string& str) const {
        std::string result = str;
        std::transform(result.begin(), result.end(), result.begin(), ::tolower);
        return result;
    }

public:
    Trie() {
        root = new TrieNode();
        std::ifstream file("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/dictionary.txt");
        if (!file.is_open()) {
            std::cerr << "Error: Could not open ";
            return;
        }

        std::string word;
        while (file >> word) {
            insert(word);
        }

        file.close();

    }

    // Insert a word into the Trie
    void insert(const std::string& word) {
        TrieNode* node = root;
        for (char c : toLower(word)) {
            if (!node->children[c]) {
                node->children[c] = new TrieNode();
            }
            node = node->children[c];
        }
        node->isEndOfWord = true;
    }

    // Check if a word is valid
    bool isValidWord(const std::string& word) const {
        TrieNode* node = root;
        for (char c : toLower(word)) {
            if (!node->children[c]) {
                return false;
            }
            node = node->children[c];
        }
        return node->isEndOfWord;
    }

    // Iterate through all words in the Trie
    void forEachWord(const std::function<void(const std::string&)>& callback, TrieNode* node = nullptr, std::string currentWord = "") const {
        if (!node) node = root;

        if (node->isEndOfWord) {
            callback(currentWord);
        }

        for (const auto& child : node->children) {
            char charKey = child.first;
            TrieNode* childNode = child.second;
            forEachWord(callback, childNode, currentWord + charKey);
        }
    }

};

sf::Font& getGlobalFont() {
    static sf::Font font;
    static bool isLoaded = false;
    if (!isLoaded) {
        if (!font.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/font.otf")) {
            std::cerr << "Error: Could not load font." << std::endl;
        }
        else {
            isLoaded = true;  // Ensure the font is only loaded once
        }
    }
    return font;
}
enum TileType {
    NORMAL,
    DOUBLE_LETTER,
    TRIPLE_LETTER,
    DOUBLE_WORD,
    TRIPLE_WORD,
    CENTRE
};
struct OccupiedTile {
    bool isOccupied; // Indicates whether this tile is occupied
    char letter;     // Stores the letter of the tile if occupied

    OccupiedTile() : isOccupied(false), letter('\0') {} // Initialize to empty
};
struct TileInfo {
    int x;
    int y;
    TileType type;
    char letter;
public:

    TileInfo() : x(0), y(0), type(NORMAL), letter('\0') {}

    TileInfo(int x, int y) : x(x), y(y), type(NORMAL), letter('\0') {}
    TileInfo(int x, int y, TileType type) : x(x), y(y), type(type), letter('\0') {}
    TileInfo(int x, int y, TileType type, char l) : x(x), y(y), type(type), letter(l) {}

    void getinfo(int xcoridnate, int ycordinate, TileType Type, char l) {
        x = xcoridnate;
        y = ycordinate;
        type = Type;
        letter = l;
    }

};

struct MoveInfo {
    std::vector<TileInfo> moveTiles; // All tiles in this move
    int score;                      // Potential score for this move

    MoveInfo() : score(0) {}
    MoveInfo(const std::vector<TileInfo>& tiles, int moveScore)
        : moveTiles(tiles), score(moveScore) {}
};
int clamp(int value, int min, int max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
}

std::vector<TileInfo> tileData = {
    {0, 0, TRIPLE_WORD}, {0, 7, TRIPLE_WORD}, {7, 7, CENTRE}, {1, 1, DOUBLE_WORD}, {2, 2, DOUBLE_WORD},{3,3,DOUBLE_WORD},{4,4,DOUBLE_WORD}
 ,{7,7,DOUBLE_WORD},{1,5,TRIPLE_LETTER},{5,5,TRIPLE_LETTER},{0,3,DOUBLE_LETTER},{7,3,DOUBLE_LETTER},{2,6,DOUBLE_LETTER},{6,6,DOUBLE_LETTER}   // Add all other tiles here
};
void configureElement(sf::RectangleShape& shape, const sf::Vector2f& position, const sf::Vector2f& size, const sf::Color& fillColor, const sf::Color& outlineColor = sf::Color::Black, float outlineThickness = 1) {
    shape.setPosition(position);
    shape.setSize(size);
    shape.setFillColor(fillColor);
    shape.setOutlineColor(outlineColor);
    shape.setOutlineThickness(outlineThickness);
}
void configureText(sf::Text& text, const sf::Font& font, const std::string& content, unsigned int charSize, const sf::Vector2f& position, const sf::Color& color) {
    text.setFont(font);
    text.setString(content);
    text.setCharacterSize(charSize);
    text.setPosition(position);
    text.setFillColor(color);
}

void showLoadingScreen(sf::RenderWindow& window, const sf::Font& font, const std::string& imagePath) {
    // Load the image texture
    sf::Texture texture;
    if (!texture.loadFromFile(imagePath)) {
        // Handle error if image loading fails
        return;
    }

    // Create a sprite to display the texture
    sf::Sprite sprite(texture);
    sf::FloatRect bounds = sprite.getLocalBounds();
    sprite.setScale(window.getSize().x / bounds.width, window.getSize().y / bounds.height);
    // Create the loading text
    sf::Text loadingText;
    loadingText.setFont(font);
    loadingText.setString("Loading...");
    loadingText.setCharacterSize(48);
    loadingText.setFillColor(sf::Color::Black);
    loadingText.setPosition(window.getSize().x / 2 - loadingText.getLocalBounds().width / 2, window.getSize().y / 2 - loadingText.getLocalBounds().height / 2);

    // Draw everything
    window.clear(sf::Color::Black);
    window.draw(sprite);  // Draw the image first
    window.draw(loadingText);  // Draw the text on top
    window.display();
}




class Button {
private:
    sf::RectangleShape shape;
    sf::Text text;
    bool isHovered;  // To track if the mouse is hovering over the button
    bool isPressed;  // To track if the button is currently pressed
    std::function<void()> onClick;  // Callback function to execute on click

public:
    Button() {
    }
    Button(const sf::Font& font, const std::string& buttonText, const sf::Vector2f& position, const sf::Vector2f& size, const sf::Color& idleColor, const sf::Color& hoverColor, const sf::Color& pressedColor, std::function<void()> onClickFunc)
        : isHovered(false), isPressed(false), onClick(onClickFunc) {
        // Configure button shape
        shape.setSize(size);
        shape.setPosition(position);
        shape.setFillColor(idleColor);
        shape.setOutlineColor(sf::Color::Black);
        shape.setOutlineThickness(1);

        // Configure button text
        text.setFont(getGlobalFont());
        text.setString(buttonText);
        text.setCharacterSize(20);
        text.setFillColor(sf::Color::Black);
        // Center the text within the button
        sf::FloatRect textRect = text.getLocalBounds();
        text.setOrigin(textRect.width / 2.0f, textRect.height / 2.0f);
        text.setPosition(position.x + size.x / 2.0f, position.y + size.y / 2.0f);
    }

    void update(const sf::Vector2f& mousePos) {
        // Determine if the button is hovered
        if (shape.getGlobalBounds().contains(mousePos)) {
            isHovered = true;
        }
        else {
            isHovered = false;
        }

        // Change the button color based on its state
        if (isPressed && isHovered) {
            // Pressed state
            shape.setFillColor(sf::Color(150, 150, 150)); // Pressed color
        }
        else if (isHovered) {
            // Hover state
            shape.setFillColor(sf::Color(255, 255, 180)); // Hover color (Light Pink)
        }
        else {
            // Idle state
            shape.setFillColor(sf::Color(240, 240, 240)); // Idle color
        }
    }

    void handleMouseButtonPressed() {
        if (isHovered) {
            isPressed = true;  // Set pressed state
        }
    }

    void handleMouseButtonReleased() {
        if (isPressed && isHovered) {
            onClick();  // Call the callback function
        }
        isPressed = false;  // Reset pressed state
    }

    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(text);
    }
};

void showErrorDialog(const std::string& message, sf::RenderWindow& mainWindow) {

    sf::SoundBuffer errorSoundBuffer;
    sf::Sound errorSound;
    if (!errorSoundBuffer.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/error(1).wav")) {
        std::cerr << "Error: Could not load error sound!" << std::endl;
    }
    else {
        errorSound.setBuffer(errorSoundBuffer);
        errorSound.play();  // Play the sound when the dialog opens
    }

    sf::RenderWindow dialog(sf::VideoMode(500, 180), "Error", sf::Style::Close);
    // Configure the gradient background
    sf::VertexArray gradient(sf::Quads, 4);
    gradient[0].position = sf::Vector2f(0, 0);
    gradient[1].position = sf::Vector2f(500, 0);
    gradient[2].position = sf::Vector2f(500, 180);
    gradient[3].position = sf::Vector2f(0, 180);

    gradient[0].color = sf::Color(173, 216, 230); // Light Blue
    gradient[1].color = sf::Color(173, 216, 230); // Light Blue
    gradient[2].color = sf::Color(230, 230, 250); // Lavender
    gradient[3].color = sf::Color(230, 230, 250); // Lavender

    // Configure the error message text
    sf::Text errorMsg;
    errorMsg.setFont(getGlobalFont());
    errorMsg.setString(message);
    errorMsg.setCharacterSize(18);
    errorMsg.setFillColor(sf::Color::Black);
    errorMsg.setPosition(40, 50);

    // Create the "OK" button
    Button okButton(
        getGlobalFont(),
        "OK",
        sf::Vector2f(200, 120), // Button position (centered below the message)
        sf::Vector2f(100, 47),  // Button size
        sf::Color(240, 240, 240), // Idle color
        sf::Color(255, 182, 193), // Hover color (Light Pink)
        sf::Color(150, 150, 150), // Pressed color
        [&dialog]() { dialog.close(); } // Close dialog on button press
    );

    // Event loop specifically for the dialog
    while (dialog.isOpen()) {
        sf::Event event;
        while (dialog.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                dialog.close();
            }
            if (event.type == sf::Event::MouseButtonPressed) {
                okButton.handleMouseButtonPressed();
            }
            if (event.type == sf::Event::MouseButtonReleased) {
                okButton.handleMouseButtonReleased();
            }
        }

        // Update button state based on mouse position
        okButton.update(sf::Vector2f(sf::Mouse::getPosition(dialog)));

        // Draw the dialog with the gradient, error message, and OK button
        dialog.clear();
        dialog.draw(gradient); // Draw gradient first
        dialog.draw(errorMsg);
        okButton.draw(dialog);
        dialog.display();
    }
}

std::string getUserInput(sf::RenderWindow& window, const std::string& prompt) {
    // Configure the gradient background
    sf::VertexArray gradient(sf::Quads, 4);
    gradient[0].position = sf::Vector2f((window.getSize().x - 400) / 2, (window.getSize().y - 100) / 2);
    gradient[1].position = sf::Vector2f((window.getSize().x + 400) / 2, (window.getSize().y - 100) / 2);
    gradient[2].position = sf::Vector2f((window.getSize().x + 400) / 2, (window.getSize().y + 100) / 2);
    gradient[3].position = sf::Vector2f((window.getSize().x - 400) / 2, (window.getSize().y + 100) / 2);

    gradient[0].color = sf::Color(173, 216, 230); // Light Blue
    gradient[1].color = sf::Color(173, 216, 230); // Light Blue
    gradient[2].color = sf::Color(230, 230, 250); // Lavender
    gradient[3].color = sf::Color(230, 230, 250); // Lavender

    // Configure the prompt text
    sf::Text promptText;
    configureText(
        promptText,
        getGlobalFont(),
        prompt,                                                                     // Prompt string
        24,                                                                         // Character size
        sf::Vector2f(gradient[0].position.x + 10, gradient[0].position.y - 30),   // Position
        sf::Color::White                                                            // Text color
    );

    // Configure the user input text
    sf::Text userInputText;
    configureText(
        userInputText, getGlobalFont(), "", 30,                                                                         // Character size
        sf::Vector2f(gradient[0].position.x + 10, gradient[0].position.y + 20),   // Position
        sf::Color::White                                                            // Text color
    );

    std::string userInput = "";

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return "";
            }

            if (event.type == sf::Event::TextEntered) {
                if (event.text.unicode == '\b') {  // Handle Backspace
                    if (!userInput.empty()) {
                        userInput.pop_back();
                    }
                }
                else if (event.text.unicode == '\r') {  // Handle Enter
                    return userInput;
                }
                else if (std::isalpha(static_cast<char>(event.text.unicode))) {
                    userInput += static_cast<char>(event.text.unicode);
                }
            }
        }

        // Update the input text
        userInputText.setString(userInput);

        // Draw the overlay
        window.clear();
        window.draw(gradient); // Draw gradient first
        window.draw(promptText);
        window.draw(userInputText);
        window.display();
    }

    return "";
}


void loadGameResources(Trie& trie) {

    trie = Trie();
}




class Tile {
public:
    sf::RectangleShape shape;
    sf::Text label, letter, scoreText;
    TileType type;
    bool isDragging = false;
    sf::Vector2f originalPosition;
    sf::Texture texture;

    bool isPlaced = false;

    Tile() : type(NORMAL) {

        shape.setSize(sf::Vector2f(TILE_SIZE - 1, TILE_SIZE - 1));
        shape.setFillColor(sf::Color::White);
        shape.setOutlineColor(sf::Color::Black);
        shape.setOutlineThickness(1);
        // Ensure the font is loaded before assigning to the text objects
        if (getGlobalFont().getInfo().family != "") {
            initializeText(letter, getGlobalFont(), 20);  // Font size adjusted for letter
            initializeText(label, getGlobalFont(), 10);   // Font size for label
            initializeText(scoreText, getGlobalFont(), 10);
        }
        else {
            std::cerr << "Font not loaded properly!" << std::endl;
        }


    }

    void setPosition(int x, int y) {
        setPosition(sf::Vector2f(x * TILE_SIZE, y * TILE_SIZE));
    }
    sf::Vector2f getPosition() const {
        return shape.getPosition();  // Returns the position of the tile shape
    }
    void setPosition(sf::Vector2f pos) {
        shape.setPosition(pos);
        letter.setPosition(pos.x + 10, pos.y + 5);
        label.setPosition(pos.x + 10, pos.y + 10);
        scoreText.setPosition(pos.x + TILE_SIZE - 12, pos.y + TILE_SIZE - 20);
        originalPosition = pos;
    }

    void setType(TileType newType) {
        type = newType;

        switch (type) {
        case DOUBLE_LETTER: updateTileAppearance(DOUBLE_LETTER_COLOR, "DL"); break;
        case TRIPLE_LETTER: updateTileAppearance(TRIPLE_LETTER_COLOR, "TL"); break;
        case DOUBLE_WORD: updateTileAppearance(DOUBLE_WORD_COLOR, "DW"); break;
        case TRIPLE_WORD: updateTileAppearance(TRIPLE_WORD_COLOR, "TW"); break;
        case CENTRE: updateTileAppearance(Centre, " "); break;
        default: updateTileAppearance(sf::Color(169, 169, 169), ""); break;
        }
    }
    TileType gettype() {

        return type;
    }
    void applyTexture(const std::string& texturePath) {
        if (texture.loadFromFile(texturePath)) {
            shape.setTexture(&texture);
        }
    }

    void setSlateTile(char letterTile) {
        shape.setFillColor(sf::Color(255, 204, 153));
        letter.setString(std::string(1, letterTile));
        //std::cout << "Letter assigned: " << letterTile << std::endl;
        // Assign score if not blank
        if (letterTile != ' ') {
            int score = getLetterScore(letterTile);
            scoreText.setString(std::to_string(score));
            // Position the score at the bottom-right corner of the tile
            sf::Vector2f pos = shape.getPosition();
            scoreText.setPosition(pos.x + TILE_SIZE - 12, pos.y + TILE_SIZE - 20);
        }
        else {
            scoreText.setString(""); // Blank tiles have no score
        }
    }

    char getletter() {
        // Get the string from the 'letter' text object
        std::string letterString = letter.getString();

        // Ensure the string is not empty before accessing the first character
        if (!letterString.empty()) {
            return letterString[0]; // Return the first character
        }

        return '\0'; // Return null character if no letter is assigned
    }


    bool containsPoint(sf::Vector2f point) {
        return shape.getGlobalBounds().contains(point);
    }
    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(letter);
        window.draw(label);
        window.draw(scoreText); // Draw the score
    }

private:
    void initializeText(sf::Text& text, sf::Font& font, int size) {
        text.setFont(font);
        text.setCharacterSize(size);
        text.setFillColor(sf::Color::Black);
    }

    void updateTileAppearance(const sf::Color& color, const std::string& labelString) {
        shape.setFillColor(color);
        label.setString(labelString);
    }

    int getLetterScore(char letter) {
        switch (toupper(letter)) {
        case 'A': case 'E': case 'I': case 'O': case 'U': case 'L': case 'N': case 'S': case 'T': case 'R': return 1;
        case 'D': case 'G': return 2;
        case 'B': case 'C': case 'M': case 'P': return 3;
        case 'F': case 'H': case 'V': case 'W': case 'Y': return 4;
        case 'K': return 5;
        case 'J': case 'X': return 8;
        case 'Q': case 'Z': return 10;
        default: return 0;
        }
    }
};
class Player {

private:
    sf::SoundBuffer scoreBuffer;
    sf::Sound scoreSound;
    std::vector<Tile> tiles;

public:
    sf::CircleShape shape;
    sf::Text nameText;      // Player name text
    sf::Text scoreText;
    sf::RectangleShape scoreBox;
    std::string name;
    bool isTurn;
    int score;              // Player's score
    sf::Texture texture;
    std::vector<Tile> getTiles() const {
        return tiles;
    }
    Player() : score(0) {
        // Load the sound buffer for score update
        if (!scoreBuffer.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/update_score.wav")) {
            std::cerr << "Error: Could not load score update sound!" << std::endl;
        }
        else {
            scoreSound.setBuffer(scoreBuffer);
        }
    }

    // Constructor
    Player(const std::string& playerName, float xPosition, float yPosition, bool ai = false)
        : name(playerName), isTurn(false), score(0) {
        isTurn = false;
        // Create the player circle
        shape.setRadius(60);  // Circle radius
        shape.setPosition(xPosition, yPosition);  // Position on the slate
        shape.setOutlineThickness(5.0);

        // Apply texture (image)
        if (!texture.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/player image (2).jpeg")) { // Replace with your image file
            std::cerr << "Error: Could not load player image!" << std::endl;
        }
        else {
            texture.setSmooth(true);
            shape.setTexture(&texture); // Apply the image as a texture
        }

        // Create the name text
        nameText.setFont(getGlobalFont());
        nameText.setString(playerName);
        nameText.setCharacterSize(14);
        nameText.setFillColor(sf::Color::Black);
        nameText.setPosition(xPosition + 40, yPosition + 140);  // Slightly below the circle

        // Create the score box
        scoreBox.setSize(sf::Vector2f(100, 40)); // Width 100, Height 40
        scoreBox.setFillColor(sf::Color::Black);
        scoreBox.setOutlineColor(sf::Color::White);
        scoreBox.setOutlineThickness(2.0);
        scoreBox.setPosition(xPosition + shape.getRadius() - 50, yPosition + shape.getRadius() * 2.8); // Position below the circle


        // Create the score text
        scoreText.setFont(getGlobalFont());
        scoreText.setCharacterSize(20);  // Set a slightly larger font size for the score
        scoreText.setFillColor(sf::Color::White);  // Set color for the score
        updateScoreText();  // Initialize the score text
        if (!scoreBuffer.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/update_score.wav")) {
            std::cerr << "Error: Could not load score update sound!" << std::endl;
        }
        else {
            scoreSound.setBuffer(scoreBuffer);
        }
    }

    // Function to update score and scoreText
    void updateScore(int newScore) {
        score += newScore;
        updateScoreText();
        // Play sound effect for score update
        if (scoreSound.getStatus() != sf::Sound::Playing) {
            scoreSound.play();
        }
    }

    // Function to update the scoreText position and text
    void updateScoreText() {
        scoreText.setString(std::to_string(score));
        float x = scoreBox.getPosition().x + (scoreBox.getSize().x - scoreText.getGlobalBounds().width) / 2;
        float y = scoreBox.getPosition().y + (scoreBox.getSize().y - scoreText.getGlobalBounds().height) / 2 - 5; // Slight vertical adjustment
        scoreText.setPosition(x, y);
    }

    // Function to draw player
    void draw(sf::RenderWindow& window) {
        if (isTurn) {
            shape.setOutlineColor(sf::Color::Red); // Red outline when it's the player's turn
        }
        else {
            shape.setOutlineColor(sf::Color::Transparent); // Transparent outline when it's not the player's turn
        }
        window.draw(scoreBox);
        window.draw(shape);     // Draw the player circle
        window.draw(nameText);  // Draw the player name
        window.draw(scoreText); // Draw the score in the center of the circle
    }
};


class Panel {
private:

    sf::RectangleShape playerPanel;
    sf::RectangleShape tileCountBox;  // Box to display tile count
    sf::Text tileCountText;           // Text to display the number of tiles
    sf::Texture tileCountTexture;     // Texture to apply an image to the tile count box
    Button submitButton;
    Button skipButton;
    Button surrenderButton;
    Button Boardscan;
    Player& player1;  // Reference to player1
    Player& player2;  // Reference to player2
public:
    Panel(Player& p1, Player& p2, std::function<void()> submitAction, std::function<void()> skipAction, std::function<void()> surrenderAction, std::function<void()> Scan) :player1(p1), player2(p2) {
        // Configure the panel and buttons
        configureElement(playerPanel, sf::Vector2f(526, 0), sf::Vector2f(370, WINDOW_HEIGHT), sf::Color(240, 240, 240), sf::Color::Black, 2);
        submitButton = Button(getGlobalFont(), "Submit", sf::Vector2f(550, 300), sf::Vector2f(100, 50), sf::Color(240, 240, 240), sf::Color(200, 200, 200), sf::Color(150, 150, 150), submitAction);
        surrenderButton = Button(getGlobalFont(), "Surrender", sf::Vector2f(550, 440), sf::Vector2f(100, 50), sf::Color(240, 240, 240), sf::Color(200, 200, 200), sf::Color(150, 150, 150), surrenderAction);
        Boardscan = Button(getGlobalFont(), "Scan", sf::Vector2f(670, 440), sf::Vector2f(50, 50), sf::Color(240, 240, 240), sf::Color(200, 200, 200), sf::Color(150, 150, 150), Scan);
        skipButton = Button(
            getGlobalFont(),
            "Skip",
            sf::Vector2f(550, 370),
            sf::Vector2f(100, 50),
            sf::Color(240, 240, 240),
            sf::Color(200, 200, 200),
            sf::Color(150, 150, 150),
            skipAction // Use the callback passed from the Game constructor
        );


        // Load the texture for the tile count box
        if (!tileCountTexture.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/tilebag.png")) {
            std::cerr << "Error: Could not load tile bag image!" << std::endl;
        }

        // Configure the tile count box with the texture
        configureElement(tileCountBox, sf::Vector2f(825, 475), sf::Vector2f(65, 65), sf::Color(240, 240, 240), sf::Color::Transparent, 2);
        tileCountBox.setTexture(&tileCountTexture);  // Apply the texture to the box

        // Configure the text to display tile count
        configureText(tileCountText, getGlobalFont(), "86", 18, sf::Vector2f(849, 501), sf::Color::White);
    }

    void drawGradient(sf::RenderWindow& window, sf::FloatRect panelRect) {
        sf::VertexArray gradient(sf::Quads, 4);

        // Positions
        gradient[0].position = sf::Vector2f(panelRect.left, panelRect.top);
        gradient[1].position = sf::Vector2f(panelRect.left + panelRect.width, panelRect.top);
        gradient[2].position = sf::Vector2f(panelRect.left + panelRect.width, panelRect.top + panelRect.height);
        gradient[3].position = sf::Vector2f(panelRect.left, panelRect.top + panelRect.height);

        // Hardcoded Lavender and Mint Green Colors
        gradient[0].color = sf::Color(216, 191, 216);  // Top-Left: Lavender
        gradient[1].color = sf::Color(216, 191, 216);  // Top-Right: Lavender
        gradient[2].color = sf::Color(173, 216, 230);  // Bottom-Right: Mint Green
        gradient[3].color = sf::Color(173, 216, 230);  // Bottom-Left: Mint Green
        // Draw the gradient
        window.draw(gradient);
    }


    void updateTileCount(int count) {
        tileCountText.setString(std::to_string(count));  // Update the text with the current count
    }

    void draw(sf::RenderWindow& window) {
        sf::FloatRect panelRect(526, 0, 370, WINDOW_HEIGHT);
        drawGradient(window, panelRect);
        playerPanel.setFillColor(sf::Color::Transparent);
        window.draw(playerPanel);        // Player panel
        submitButton.draw(window);       // Submit button
        skipButton.draw(window);         // Skip button
        surrenderButton.draw(window);    // Surrender button
        Boardscan.draw(window);
        window.draw(tileCountBox);       // Tile count box
        window.draw(tileCountText);      // Tile count text
    }



    void update(const sf::Vector2f& mousePos) {
        submitButton.update(mousePos);
        skipButton.update(mousePos);
        surrenderButton.update(mousePos);
        Boardscan.update(mousePos);
    }

    void handleMouseButtonPressed() {
        submitButton.handleMouseButtonPressed();
        skipButton.handleMouseButtonPressed();
        surrenderButton.handleMouseButtonPressed();
        Boardscan.handleMouseButtonPressed();
    }

    void handleMouseButtonReleased() {
        submitButton.handleMouseButtonReleased();
        skipButton.handleMouseButtonReleased();
        surrenderButton.handleMouseButtonReleased();
        Boardscan.handleMouseButtonReleased();
    }

    void updatePlayerScore(Player& player, int newScore) {
        player.updateScore(newScore);

    }


};



class Board {
private:
    std::vector<std::vector<Tile>> grid;
    std::vector<std::vector<OccupiedTile>> occupiedGrid;

    Tile* draggedTile;  // Track which tile is being dragged
    //std::vector<std::vector<Tile>> grid;  // 2D grid for the board

    void setSymmetricTiles(int r, int c, TileType type) {
        grid[r][c].setType(type);
        grid[14 - r][c].setType(type);
        grid[r][14 - c].setType(type);
        grid[14 - r][14 - c].setType(type);
        if (r != c) {

            grid[c][r].setType(type);
            grid[14 - c][r].setType(type);
            grid[c][14 - r].setType(type);
            grid[14 - c][14 - r].setType(type);
        }
    }

public:

    // Add a method to update a specific tile in the grid
    void updateGridTile(int row, int col, Tile& tile, char letter) {
        // Copy the placed tile's properties into the grid at (row, col)
        grid[row][col] = tile;
        grid[row][col].letter.setString(std::string(1, letter));
        // Set the letter explicitly
        grid[row][col].label.setString(std::string(1, letter)); // Set the letter
        grid[row][col].label.setFont(getGlobalFont());  // Ensure the font is set
        grid[row][col].label.setCharacterSize(18);;
        occupiedGrid[row][col].isOccupied = true;
        occupiedGrid[row][col].letter = letter;
        //std::cout << "Tile updated at (" << row << ", " << col << ") with letter: " << letter <<"status:"<< occupiedGrid[row][col].isOccupied << std::endl;
    }


    bool isTileOccupied(int x, int y) const {
        // Ensure coordinates are within board boundaries
        if (x < 0 || x >= GRID_SIZE || y < 0 || y >= GRID_SIZE) {
            return false; // Out-of-bounds positions are considered unoccupied
        }

        // Check if the specified tile is occupied
        return occupiedGrid[y][x].isOccupied;
    }
    TileInfo getinfo(int x, int y, TileInfo T) {
        T.x = x;
        T.y = y;
        T.letter = occupiedGrid[y][x].letter;
        T.type = NORMAL;
        return T;
    }
    TileType getTileType(int x, int y) {

        // Return the tile type at the specified coordinates
        return grid[y][x].gettype();
    }
    Board() : draggedTile(nullptr), grid(GRID_SIZE, std::vector<Tile>(GRID_SIZE)),
        occupiedGrid(GRID_SIZE, std::vector<OccupiedTile>(GRID_SIZE)) {
        grid.resize(GRID_SIZE, std::vector<Tile>(GRID_SIZE, Tile()));

        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                grid[row][col].setPosition(col, row + 1);  // Shift board down by 1 row to leave space for top slate
            }
        }
        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                occupiedGrid[row][col] = OccupiedTile(); // Default constructor already initializes it
            }
        }

        for (const TileInfo& info : tileData) {
            setSymmetricTiles(info.x, info.y, info.type);
        }
        // Change this part
        grid[7][7].applyTexture("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/star.jpeg"); // Set the star image
        grid[7][7].setType(CENTRE);
        grid[7][7].setType(CENTRE); // Center tile

        // Set Double, Triple Letter, and Word tiles in relevant positions
        grid[1][1].setType(DOUBLE_LETTER);
        grid[13][13].setType(DOUBLE_LETTER);
        grid[3][0].setType(DOUBLE_WORD);
        grid[14][14].setType(TRIPLE_WORD);
    }

    void CheckforColumn(int x, int y, std::vector<TileInfo>& placedTilesInfo, int a) {
        while (x >= 0 && x < GRID_SIZE && occupiedGrid[y][x].isOccupied) {
            TileInfo T(x, y);
            T.x = x;
            T.y = y;
            T = getinfo(T.x, T.y, T);
            placedTilesInfo.push_back(T);
            x += a;
        }
    }
    void CheckforRow(int x, int y, std::vector<TileInfo>& placedTilesInfo, int a) {
        while (y >= 0 && y < GRID_SIZE && occupiedGrid[y][x].isOccupied) {
            TileInfo T(x, y);
            T.x = x;
            T.y = y;
            T = getinfo(x, y, T);
            placedTilesInfo.push_back(T);
            y += a;
        }
    }
    bool areTilesOccupiedInRange(int startX, int startY, int endX, int endY) {
        // Vertical check (same column)
        if (startX == endX) {
            for (int y = startY + 1; y < endY; ++y) {
                if (!occupiedGrid[y][startX].isOccupied) {
                    return false; // Found an unoccupied tile
                }
            }
        }
        // Horizontal check (same row)
        else {
            for (int x = startX + 1; x < endX; ++x) {
                if (!occupiedGrid[startY][x].isOccupied) {
                    return false; // Found an unoccupied tile
                }
            }
        }

        return true; // All tiles in range are occupied
    }

    void findPossibleMoveSpaces() {
        clearHighlights(); // Reset all previous highlights

        // Iterate over the grid to find occupied tiles
        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                if (occupiedGrid[row][col].isOccupied) {
                    // Check and highlight tiles in all four directions
                    highlightDirectionWithBonuses(row, col, 0, -1); // Up
                    highlightDirectionWithBonuses(row, col, 0, 1);  // Down
                    highlightDirectionWithBonuses(row, col, -1, 0); // Left
                    highlightDirectionWithBonuses(row, col, 1, 0);  // Right
                }
            }
        }
    }
    void highlightDirectionWithBonuses(int row, int col, int deltaX, int deltaY) {
        int newRow = row + deltaY;
        int newCol = col + deltaX;
        int tilesHighlighted = 0; // Counter for highlighted tiles (7 max)

        // Move in the specified direction
        while (newRow >= 0 && newRow < GRID_SIZE &&
            newCol >= 0 && newCol < GRID_SIZE &&
            !occupiedGrid[newRow][newCol].isOccupied &&
            tilesHighlighted < 7) { // Stop after 7 tiles

            // Check if the tile is a bonus tile
            TileType tileType = grid[newRow][newCol].gettype();

            if (tileType == DOUBLE_LETTER || tileType == TRIPLE_LETTER) {
                grid[newRow][newCol].shape.setOutlineThickness(2);
                grid[newRow][newCol].shape.setOutlineColor(sf::Color::Blue); // Prioritize letter bonus
            }
            else if (tileType == DOUBLE_WORD || tileType == TRIPLE_WORD) {
                grid[newRow][newCol].shape.setOutlineThickness(2);
                grid[newRow][newCol].shape.setOutlineColor(sf::Color::Red); // Prioritize word bonus
            }
            else {
                // Default highlighting for normal empty tiles
                grid[newRow][newCol].shape.setOutlineThickness(2);
                grid[newRow][newCol].shape.setOutlineColor(sf::Color::Green);
            }

            // Increment counter and move further in the same direction
            tilesHighlighted++;
            newRow += deltaY;
            newCol += deltaX;
        }
    }
    vector<vector<TileInfo>> findAllPossibleMoves() {
        std::vector<std::vector<TileInfo>> allMoves;

        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                if (occupiedGrid[row][col].isOccupied) {
                    // Scan in all 4 directions
                    scanDirection(row, col, 0, -1, allMoves); // Up
                    scanDirection(row, col, 0, 1, allMoves);  // Down
                    scanDirection(row, col, -1, 0, allMoves); // Left
                    scanDirection(row, col, 1, 0, allMoves);  // Right
                }
            }
        }

        return allMoves; // Return all valid moves
    }
    void scanDirection(int row, int col, int deltaX, int deltaY, vector<vector<TileInfo>>& moves) {
        std::vector<TileInfo> moveTiles; // Tiles in this move
        int newRow = row + deltaY;
        int newCol = col + deltaX;

        // Scan for up to 7 tiles
        for (int i = 0; i < 7; ++i) {
            if (newRow < 0 || newRow >= GRID_SIZE || newCol < 0 || newCol >= GRID_SIZE) break; // Out of bounds
            if (occupiedGrid[newRow][newCol].isOccupied) break; // Stop at occupied tile

            // Add tile info to this move
            TileType type = grid[newRow][newCol].gettype();
            moveTiles.emplace_back(newRow, newCol, type);

            // Move to the next tile in this direction
            newRow += deltaY;
            newCol += deltaX;
        }

        // Save this move if tiles were found
        if (!moveTiles.empty()) {
            moves.push_back(moveTiles);
        }
    }
    void clearHighlights() {
        // Reset the tile highlights after drawing
        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                grid[row][col].shape.setOutlineThickness(1);
                grid[row][col].shape.setOutlineColor(sf::Color::Black);

            }
        }
    }


    void draw(sf::RenderWindow& window) {
        for (int row = 0; row < GRID_SIZE; ++row) {
            for (int col = 0; col < GRID_SIZE; ++col) {
                window.draw(grid[row][col].shape);
                window.draw(grid[row][col].label);
                window.draw(grid[row][col].scoreText);
            }
        }


    }
};

class Menu {
private:
    sf::RectangleShape background;
    sf::Text titleText;
    sf::Font bubbleFont;
    Button play;
    Button quitGameButton;
    Player& player1;  // Reference to player1
    Player& player2;  // Reference to player2
    Player* currentPlayer;
    Board board;


    void configureElement(sf::RectangleShape& element, sf::Vector2f position, sf::Vector2f size, sf::Color fillColor, sf::Color outlineColor, float outlineThickness) {
        element.setPosition(position);
        element.setSize(size);
        element.setFillColor(fillColor);
        element.setOutlineColor(outlineColor);
        element.setOutlineThickness(outlineThickness);
    }

    void configureText(sf::Text& text, const sf::Font& font, const std::string& string, unsigned int fontSize, sf::Vector2f position, sf::Color color) {
        text.setFont(font);
        text.setString(string);
        text.setCharacterSize(fontSize);
        text.setPosition(position);
        text.setFillColor(color);
    }

public:
    bool isMenuVisible;
    Menu(Player& p1, Player& p2) : isMenuVisible(true), player1(p1), player2(p2), currentPlayer(&player1) {
        std::cout << "Menu Initialized!" << std::endl; // Debugging output
        configureElement(
            background,
            sf::Vector2f(150, 100),
            sf::Vector2f(600, 400),
            sf::Color(139, 0, 20),
            sf::Color::Black,
            2
        );

        if (!bubbleFont.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/panel font.ttf")) {
            std::cerr << "Error: Could not load the bubble font." << std::endl;
            return;
        }

        configureText(
            titleText,
            bubbleFont,
            "SCRABBLE",
            48,
            sf::Vector2f(370, 120),
            sf::Color(255, 215, 0)
        );

        play = Button(
            bubbleFont,
            "Play",
            sf::Vector2f(269, 250),
            sf::Vector2f(350, 50),
            sf::Color(240, 240, 240),
            sf::Color(200, 200, 200),
            sf::Color(150, 150, 150),
            [&]() { handlePlay(); }
        );

        quitGameButton = Button(
            bubbleFont,
            "Quit Game",
            sf::Vector2f(300, 350),
            sf::Vector2f(300, 50),
            sf::Color(240, 240, 240),
            sf::Color(200, 200, 200),
            sf::Color(150, 150, 150),
            [&]() { handleQuitGame(); }
        );
    }


    bool isVisible() const {
        return isMenuVisible;
    }

    void handlePlay() {
        // Hide the menu and start the game
        isMenuVisible = false;
    }

    void handleQuitGame() {
        std::cout << "Quitting the game!" << std::endl;
        isMenuVisible = false;
        exit(0);
    }

    void update(const sf::Vector2f& mousePos) {
        if (isMenuVisible) {
            play.update(mousePos);
            quitGameButton.update(mousePos);
        }
    }

    void handleMouseButtonPressed() {
        if (isMenuVisible) {
            play.handleMouseButtonPressed();
            quitGameButton.handleMouseButtonPressed();
        }
    }

    void handleMouseButtonReleased() {
        if (isMenuVisible) {
            play.handleMouseButtonReleased();
            quitGameButton.handleMouseButtonReleased();
        }
    }

    void draw(sf::RenderWindow& window) {
        if (isMenuVisible) {
            window.draw(background);
            window.draw(titleText);
            play.draw(window);
            quitGameButton.draw(window);
        }
    }
};

void printMouseCoordinates(sf::Vector2f mousePos) {
    cout << "" << "";
    // Convert mouse position to grid coordinates
    int gridX = static_cast<int>(std::floor(mousePos.x / TILE_SIZE));
    int gridY = static_cast<int>(std::floor(mousePos.y / TILE_SIZE));
    gridX = clamp(gridX, 0, GRID_SIZE - 1);
    gridY = clamp(gridY, 0, GRID_SIZE - 1);
    std::cout << "Mouse Coordinates: (" << mousePos.x << ", " << mousePos.y
        << ") Grid: (" << gridY << ", " << gridX << ")" << std::endl;
}

class Slate {
private:
    Player* owner;
    std::vector<Tile> tiles;
    std::vector<char> tileBag;
    int y;
    int x;
    Tile* draggedTile;  // Track which tile is being dragged
    Board* board;
public:
    Slate() {}
    Slate(int startX, int startY, std::vector<char>& tileBag, Player* player, Board* gameBoard)
        : owner(player), board(gameBoard) {
        tiles.resize(SLATE_TILE_COUNT, Tile());
        // Print size of the bag before drawing
       // std::cout << "Tile bag size before drawing: " << tileBag.size() << std::endl;
        std::vector<char> letters = drawTiles(tileBag, SLATE_TILE_COUNT);
        for (int i = 0; i < SLATE_TILE_COUNT; ++i) {
            tiles[i].setSlateTile(letters[i]);
            tiles[i].setPosition(i + 4, startY);
        }
        y = startY;
        x = startX;
        // Print size of the bag after drawing
        //std::cout << "Tile bag size after drawing: " << tileBag.size() << std::endl;
        draggedTile = nullptr;
    }
    // Function to collect information about placed tiles
    std::vector<TileInfo> collectPlacedTileInfo() {
        std::vector<TileInfo> placedTilesInfo; // Vector to store the information of placed tiles

        for (Tile& tile : tiles) {
            if (tile.isPlaced) {
                // Calculate the grid position where the tile was placed
                int gridX = static_cast<int>(tile.getPosition().x / TILE_SIZE);
                int gridY = static_cast<int>((tile.getPosition().y - TILE_SIZE) / TILE_SIZE);

                // Get the letter from the tile
                char placedLetter = tile.getletter();
                TileType t = board->getTileType(gridX, gridY);
                // Create a TileInfo object and add it to the vector
                placedTilesInfo.emplace_back(gridX, gridY, t, placedLetter);

                // Optionally print debug information
                //std::cout << "Collected TileInfo: Letter " << placedLetter << " at (" << gridY << ", " << gridX << ")\n";
            }
        }
        return placedTilesInfo; // Return the collected information
    }
    // In Slate class
    std::vector<TileInfo> clearPlacedTiles(std::vector<TileInfo>& placedTiles) {
        placedTiles.clear(); // Clear the contents of the vector
        return placedTiles;  // Return the cleared vector
    }

    std::string getRackLetters() {
        std::string rack;
        char letter;
        for (Tile& tile : tiles) {
            if (!tile.isPlaced) {
                rack += tile.getletter();
                cout << "letter :" << tile.getletter();
            }
        }
        return rack;
    }

    void refillTiles(std::vector<char>& tileBag) {
        int usedTiles = 0;

        // Count how many tiles are placed
        for (const Tile& tile : tiles) {
            if (tile.isPlaced) {
                usedTiles++;
            }
        }

        // Update the board for all placed tiles
        for (Tile& tile : tiles) {
            if (tile.isPlaced) {
                // Calculate the grid position where the tile was placed
                int gridX = static_cast<int>(tile.getPosition().x / TILE_SIZE);
                int gridY = static_cast<int>((tile.getPosition().y - TILE_SIZE) / TILE_SIZE);

                // Update the board with the placed tile (you can get the letter from the tile)
                char placedLetter = tile.getletter();
                board->updateGridTile(gridY, gridX, tile, placedLetter);
            }
        }

        // Check if there are enough tiles in the bag
        if (tileBag.empty()) {
            std::cout << "Tile bag is empty. No tiles will be refilled." << std::endl;
            return; // No tiles to refill
        }

        // Limit the number of tiles to draw based on the available tiles in the bag
        int tilesToDraw = std::min(usedTiles, static_cast<int>(tileBag.size()));

        // Draw new tiles from the tile bag
        std::vector<char> letters = drawTiles(tileBag, tilesToDraw);

        int index = 0;
        // Iterate over all tiles and replace the placed ones with new letters
        for (int i = 0; i < tiles.size(); i++) {
            if (tiles[i].isPlaced && index < letters.size()) {
                // Set new tile and reset placement status
                tiles[i].setSlateTile(letters[index]);
                tiles[i].isPlaced = false;
                index++;
            }
        }

        // Log if not all tiles could be replaced
        if (index < usedTiles) {
            std::cout << "Not enough tiles in the bag to refill all used tiles. "
                << (usedTiles - index) << " tiles remain unfilled." << std::endl;
        }

        // Update the positions of the tiles (assuming 'y' is defined)
        for (int i = 0; i < tiles.size(); i++) {
            tiles[i].setPosition(i + 4, y);
        }
    }

    void snapTileToNearestGrid(Tile& tile, int mouseX, int mouseY) {
        // Snap x and y coordinates to the nearest grid position
        int snappedX = (mouseX / TILE_SIZE) * TILE_SIZE;
        int snappedY = (mouseY / TILE_SIZE) * TILE_SIZE;

        // Ensure the snapped position is within grid boundaries
        if (snappedX < 0) snappedX = 0;
        if (snappedX > (GRID_SIZE - 1) * TILE_SIZE) snappedX = (GRID_SIZE - 1) * TILE_SIZE;
        if (snappedY < TILE_SIZE) snappedY = TILE_SIZE;  // Prevent snapping above the grid
        if (snappedY > GRID_SIZE * TILE_SIZE) snappedY = GRID_SIZE * TILE_SIZE;

        // Update tile's position and placement status
        tile.setPosition(sf::Vector2f(snappedX, snappedY));
        tile.isPlaced = true;

        // Log confirmation (optional)
        std::cout << "Tile snapped to grid at: (" << snappedY / TILE_SIZE << ", "
            << snappedX / TILE_SIZE << ")" << std::endl;
    }


    void handleMousePress(sf::Vector2f mousePos) {
        if (owner->isTurn) {  // Only allow dragging if this player's turn
            for (Tile& tile : tiles) {
                if (tile.containsPoint(mousePos) && (tile.isPlaced || !tile.isPlaced)) {
                    draggedTile = &tile;
                    draggedTile->isDragging = true;
                    return;
                }
            }
        }
    }

    void handleAIMousePress() {
        if (owner->isTurn) {  // Only allow placing if it's this player's turn
            for (Tile& tile : tiles) {
                tile.isDragging = true;  // Mark all tiles as ready for placement
            }
        }
    }
    void handleAIMouseRelease(sf::RenderWindow& window) {
        int gridX = 0, gridY = 0;  // Start placing from the top-left grid

        for (Tile& tile : tiles) {
            // Skip tiles already placed
            if (tile.isPlaced) continue;

            // Calculate position based on grid coordinates
            int newX = gridX * TILE_SIZE;
            int newY = (gridY + 1) * TILE_SIZE;  // Offset by TILE_SIZE for board boundary

            // Set bounds for the grid
            if (newX > (GRID_SIZE - 1) * TILE_SIZE) {
                gridX = 0;  // Reset to first column
                gridY++;    // Move to the next row
                newX = gridX * TILE_SIZE;
                newY = (gridY + 1) * TILE_SIZE;
            }

            // Snap tile to grid position
            tile.setPosition(sf::Vector2f(newX, newY));
            tile.isPlaced = true;

            // Handle blank tiles
            char placedLetter = tile.getletter();
            if (placedLetter == ' ') {  // Blank tile check
                std::string enteredLetter = getUserInput(window, "Enter a letter for the blank tile:");
                if (!enteredLetter.empty() && enteredLetter.length() == 1) {
                    placedLetter = std::toupper(enteredLetter[0]);
                    tile.setSlateTile(placedLetter);
                }
            }

            // Log confirmation
            std::cout << placedLetter << " Tile placed at: (" << gridY << ", " << gridX << ")" << std::endl;

            // Move to the next grid cell
            gridX++;
        }

        // Reset dragging status
        for (Tile& tile : tiles) {
            tile.isDragging = false;
        }
    }


    void handleMouseRelease(sf::Vector2f mousePos, sf::RenderWindow& window) {
        if (draggedTile) {
            if (mousePos.y < TILE_SIZE || mousePos.y > GRID_SIZE * TILE_SIZE) {
                // Return the tile to its original position on the slate
                draggedTile->setPosition(draggedTile->originalPosition);
                draggedTile->isPlaced = false;
            }
            else {
                // Snap to the nearest grid position
                int newX = static_cast<int>(mousePos.x / TILE_SIZE) * TILE_SIZE;
                int newY = static_cast<int>(mousePos.y / TILE_SIZE) * TILE_SIZE;

                // Ensure bounds
                if (newX < 0) newX = 0;
                if (newX > (GRID_SIZE - 1) * TILE_SIZE) newX = (GRID_SIZE - 1) * TILE_SIZE;
                if (newY < TILE_SIZE) newY = TILE_SIZE;
                if (newY > GRID_SIZE * TILE_SIZE) newY = GRID_SIZE * TILE_SIZE;

                // Set the tile position
                draggedTile->setPosition(sf::Vector2f(newX, newY));
                draggedTile->isPlaced = true;

                // Get the letter from the dragged tile
                char placedLetter = draggedTile->getletter();

                // Check if the placed tile is blank
                if (placedLetter == ' ') {  // Assuming blank tiles are represented by a space
                    std::string enteredLetter = getUserInput(window, "Enter a letter for the blank tile:");
                    if (!enteredLetter.empty() && enteredLetter.length() == 1) {
                        placedLetter = std::toupper(enteredLetter[0]);  // Convert to uppercase
                        draggedTile->setSlateTile(placedLetter);  // Set the letter for the blank tile
                    }
                }

                // Calculate grid coordinates
                int gridX = newX / TILE_SIZE;  // column
                int gridY = (newY - TILE_SIZE) / TILE_SIZE;  // row (shifted down)

                // Log confirmation
                std::cout << placedLetter << " Tile placed on grid at: (" << gridY << ", " << gridX << ")" << std::endl;
            }

            draggedTile->isDragging = false;
            draggedTile = nullptr;
        }
    }


    void placeTilesOnBoard(const std::vector<std::vector<TileInfo>>& moves, sf::RenderWindow& window) {
        if (!owner->isTurn) {
            std::cout << "Not your turn. Skipping placement.\n";
            return;
        }

        std::cout << "Starting tile placement...\n";

        for (const auto& moveRow : moves) {
            for (const TileInfo& tileInfo : moveRow) {
                // Debug: Original TileInfo
                std::cout << "TileInfo Coordinates: (" << tileInfo.x << ", " << tileInfo.y
                    << ") Letter: '" << tileInfo.letter << "'\n";

                // Snap to grid center (center of each tile)
                int snappedX = (tileInfo.x / TILE_SIZE) * TILE_SIZE + TILE_SIZE / 2; // Snap to center X
                int snappedY = (tileInfo.y / TILE_SIZE) * TILE_SIZE + TILE_SIZE / 2; // Snap to center Y


                // Clamp within board bounds
                snappedX = clamp(snappedX, 0, (GRID_SIZE - 1) * TILE_SIZE);
                snappedY = clamp(snappedY, 0, (GRID_SIZE - 1) * TILE_SIZE);

                // Debug: Snapped and clamped coordinates
                std::cout << "Snapped and Clamped Coordinates: (" << snappedX << ", " << snappedY << ")\n";

                // Place the tile
                bool tilePlaced = false;
                for (Tile& tile : tiles) {
                    if (!tile.isPlaced) {  // Place only unplaced tiles
                        tile.setPosition(sf::Vector2f(snappedX, snappedY));
                        tile.isPlaced = true;
                        tile.setSlateTile(tileInfo.letter);

                        // Debug: Final Grid Position
                        std::cout << "Tile '" << tileInfo.letter << "' placed at Grid: ("
                            << snappedY / TILE_SIZE << ", " << snappedX / TILE_SIZE << ")\n";
                        tilePlaced = true;
                        break;
                    }
                }

                if (!tilePlaced) {
                    std::cerr << "Error: No available unplaced tiles for letter: " << tileInfo.letter << "\n";
                }
            }
        }

        std::cout << "Tile placement complete.\n";
    }


    void handleMouseMove(sf::Vector2f mousePos) {
        if (draggedTile && draggedTile->isDragging) {
            draggedTile->setPosition(mousePos - sf::Vector2f(TILE_SIZE / 2, TILE_SIZE / 2));  // Center tile on cursor
        }
    }

    void draw(sf::RenderWindow& window) {
        // Draw tiles in the slate
        for (Tile& tile : tiles) {
            window.draw(tile.shape);
            window.draw(tile.letter);
            window.draw(tile.label);
            window.draw(tile.scoreText);
        }
    }

    std::vector<Tile>& getTiles() {
        return tiles;
    }
};
struct AlignmentInfo {
    bool isSameRow;
    bool isSameColumn;
};
class Valid {
public:
    AlignmentInfo rowColumnCheck(const std::vector<TileInfo>& placedTilesInfo) {
        AlignmentInfo alignment = { true, true }; // Initialize to assume both same row and column

        if (placedTilesInfo.empty()) {
            return { false, false }; // No tiles placed, invalid placement
        }

        int firstRow = placedTilesInfo[0].y;
        int firstColumn = placedTilesInfo[0].x;

        // Check row alignment
        for (const auto& tile : placedTilesInfo) {
            if (tile.y != firstRow) {
                alignment.isSameRow = false;
                break;
            }
        }

        // Check column alignment
        for (const auto& tile : placedTilesInfo) {
            if (tile.x != firstColumn) {
                alignment.isSameColumn = false;
                break;
            }
        }

        return alignment;
    }
    void removeDuplicateTiles(std::vector<TileInfo>& tiles) {
        // Sort the vector based on tile positions (x, y)
        std::sort(tiles.begin(), tiles.end(), [](const TileInfo& a, const TileInfo& b) {
            if (a.x == b.x) return a.y < b.y; // Compare by y if x is the same
            return a.x < b.x;                 // Otherwise, compare by x
            });

        // Use std::unique to remove adjacent duplicates
        auto it = std::unique(tiles.begin(), tiles.end(), [](const TileInfo& a, const TileInfo& b) {
            return a.x == b.x && a.y == b.y; // Tiles are duplicates if their x and y are the same
            });

        // Erase the duplicates from the vector
        tiles.erase(it, tiles.end());
    }
    bool emptycheck(std::vector<TileInfo>& placedTilesInfo) {
        if (placedTilesInfo.empty()) {
            std::cout << "No tiles placed.\n";


            return true;
        }

    }
    bool Gap(std::vector<TileInfo>& placedTilesInfo, Board& board, sf::RenderWindow& window) {
        // Use rowColumnCheck to get alignment information
        AlignmentInfo alignment = rowColumnCheck(placedTilesInfo);

        // If tiles are neither in the same row nor the same column, there's no valid placement
        if (!alignment.isSameRow && !alignment.isSameColumn) {

            std::cout << "Invalid tile placement. Tiles must be in the same row or column.\n";
            return false;
        }

        // If tiles are in the same row, sort by x-coordinate
        if (alignment.isSameRow) {
            std::sort(placedTilesInfo.begin(), placedTilesInfo.end(), [](const TileInfo& a, const TileInfo& b) {
                return a.x < b.x;
                });

            // Check for gaps in x-coordinates
            for (size_t i = 1; i < placedTilesInfo.size(); ++i) {
                int gap = placedTilesInfo[i].x - placedTilesInfo[i - 1].x;
                if (gap > 1) {
                    std::cout << "Gap detected between tiles at ("
                        << placedTilesInfo[i - 1].x << ", " << placedTilesInfo[i - 1].y
                        << ") and (" << placedTilesInfo[i].x << ", " << placedTilesInfo[i].y << ") - gap: "
                        << gap - 1 << "\n";

                    // Check if the tiles in the gap are occupied
                    bool occupied = board.areTilesOccupiedInRange(placedTilesInfo[i - 1].x, placedTilesInfo[i - 1].y,
                        placedTilesInfo[i].x, placedTilesInfo[i].y);
                    if (!occupied) {
                        std::cout << "Gap found between occupied tiles at ("
                            << placedTilesInfo[i - 1].x << ", " << placedTilesInfo[i - 1].y << ") and ("
                            << placedTilesInfo[i].x << ", " << placedTilesInfo[i].y << ") - some tiles are unoccupied.\n";
                        return false;  // Return false if there's an unoccupied gap
                    }
                }
            }
        }
        // If tiles are in the same column, sort by y-coordinate
        else if (alignment.isSameColumn) {
            std::sort(placedTilesInfo.begin(), placedTilesInfo.end(), [](const TileInfo& a, const TileInfo& b) {
                return a.y < b.y;
                });

            // Check for gaps in y-coordinates
            for (size_t i = 1; i < placedTilesInfo.size(); ++i) {
                int gap = placedTilesInfo[i].y - placedTilesInfo[i - 1].y;
                if (gap > 1) {
                    std::cout << "Gap detected between tiles at ("
                        << placedTilesInfo[i - 1].x << ", " << placedTilesInfo[i - 1].y
                        << ") and (" << placedTilesInfo[i].x << ", " << placedTilesInfo[i].y << ") - gap: "
                        << gap - 1 << "\n";

                    // Check if the tiles in the gap are occupied
                    bool occupied = board.areTilesOccupiedInRange(placedTilesInfo[i - 1].x, placedTilesInfo[i - 1].y,
                        placedTilesInfo[i].x, placedTilesInfo[i].y);
                    if (!occupied) {
                        std::cout << "Gap found between occupied tiles at ("
                            << placedTilesInfo[i - 1].x << ", " << placedTilesInfo[i - 1].y << ") and ("
                            << placedTilesInfo[i].x << ", " << placedTilesInfo[i].y << ") - some tiles are unoccupied.\n";
                        return false;  // Return false if there's an unoccupied gap
                    }
                }
            }
        }

        // If no gaps were found, return true
        return true;
    }
    bool isTilePlacedAt(const std::vector<TileInfo>& placedTilesInfo, int x, int y) {
        for (const auto& tile : placedTilesInfo) {
            if (tile.x == x && tile.y == y) {
                return true; // Tile found at the given coordinates
            }
        }
        return false; // Tile not found at the given coordinates
    }
    bool isConnectedToExistingTiles(const std::vector<TileInfo>& placedTilesInfo, const Board& board) {
        bool isAdjacent = false;
        for (const auto& tile : placedTilesInfo) {
            isAdjacent = false;

            // Check adjacent tiles for occupancy
            if ((board.isTileOccupied(tile.x - 1, tile.y) ||  // Left
                board.isTileOccupied(tile.x + 1, tile.y) ||  // Right
                board.isTileOccupied(tile.x, tile.y - 1) ||  // Above
                board.isTileOccupied(tile.x, tile.y + 1)))
            {
                isAdjacent = true;
                return true;
            }


        }
        if (!isAdjacent) {
            std::cout << "Tile at () is not adjacent to any occupied tiles.\n";
            return false;
        }
        return true;
    }
    void Move(std::vector<TileInfo>& placedTilesInfo, Board& board, std::vector<TileInfo>& movetiles) {

        // If there is only one tile, we should treat it as a special case
        if (placedTilesInfo.size() == 1) {
            TileInfo tile = placedTilesInfo[0];
            std::cout << "Single tile placed: (" << tile.x << ", " << tile.y << ")" << std::endl;

            // Check left
            if (board.isTileOccupied(tile.x - 1, tile.y)) {
                std::cout << "Tile occupied left of (" << tile.x << ", " << tile.y << ")" << std::endl;
                board.CheckforColumn(tile.x - 1, tile.y, placedTilesInfo, -1);
            }
            // Check right
            if (board.isTileOccupied(tile.x + 1, tile.y)) {
                std::cout << "Tile occupied right of (" << tile.x << ", " << tile.y << ")" << std::endl;
                board.CheckforColumn(tile.x + 1, tile.y, placedTilesInfo, 1);
            }
            // Check top
            if (board.isTileOccupied(tile.x, tile.y - 1)) {
                std::cout << "Tile occupied above (" << tile.x << ", " << tile.y << ")" << std::endl;
                board.CheckforRow(tile.x, tile.y - 1, placedTilesInfo, -1);
            }
            // Check bottom
            if (board.isTileOccupied(tile.x, tile.y + 1)) {
                std::cout << "Tile occupied below (" << tile.x << ", " << tile.y << ")" << std::endl;
                board.CheckforRow(tile.x, tile.y + 1, placedTilesInfo, 1);
            }

            // Now, add the tile to placedTilesInfo
            if (board.isTileOccupied(tile.x, tile.y)) {
                TileInfo existingTile(-1, 1);
                existingTile = board.getinfo(tile.x, tile.y, existingTile);
                std::cout << "Adding existing tile: (" << existingTile.x << ", " << existingTile.y << ")" << std::endl;
                placedTilesInfo.push_back(existingTile);
            }

            return;  // Exit after processing the single tile
        }
        else {
            // Check if tiles are aligned in a row or column
            AlignmentInfo alignment = rowColumnCheck(placedTilesInfo);
            std::cout << "Tiles alignment: " << (alignment.isSameRow ? "Same Row" : (alignment.isSameColumn ? "Same Column" : "Not aligned")) << std::endl;

            // Handle the case where multiple tiles are placed in a row or column
            if (alignment.isSameRow) {
                std::cout << "Tiles are in the same row" << std::endl;
                std::sort(placedTilesInfo.begin(), placedTilesInfo.end(), [](const TileInfo& a, const TileInfo& b) {
                    return a.x < b.x;
                    });

                // Get the range of x-values to check for occupied tiles
                int y = placedTilesInfo[0].y;
                int startX = placedTilesInfo.front().x;
                int endX = placedTilesInfo.back().x;
                std::cout << "Checking between x = " << startX + 1 << " and x = " << endX << " at y = " << y << std::endl;

                // Traverse between the placed tiles in the same row
                for (int x = startX + 1; x < endX; ++x) {
                    if (board.isTileOccupied(x, y) && !isTilePlacedAt(placedTilesInfo, x, y)) {
                        std::cout << "Tile occupied at: (" << x << ", " << y << ")" << std::endl;
                        TileInfo existingTile(x, y);
                        existingTile.x = x;
                        existingTile.y = y;
                        existingTile = board.getinfo(x, y, existingTile);
                        placedTilesInfo.push_back(existingTile);
                    }
                }

                // Check neighboring tiles
                for (const auto& tile : movetiles) {
                    cout << "checking for tile (" << tile.x << ", " << tile.y << ")" << endl;
                    if (!board.isTileOccupied(tile.x, tile.y)) {
                        if (board.isTileOccupied(tile.x, tile.y - 1))
                        {
                            std::cout << "Tile occupied above: (" << tile.x << ", " << tile.y << ")" << std::endl;
                            board.CheckforColumn(tile.x, tile.y - 1, placedTilesInfo, -1);

                        }
                        if (board.isTileOccupied(tile.x, tile.y + 1)) {
                            std::cout << "Tile occupied below: (" << tile.x << ", " << tile.y << ")" << std::endl;

                            board.CheckforColumn(tile.x, tile.y + 1, placedTilesInfo, 1);
                        }
                    }
                }
                for (const auto& tile : movetiles) {
                    cout << "checking for tile (" << tile.x << ", " << tile.y << ")" << endl;
                    if (!board.isTileOccupied(tile.x, tile.y)) {
                        if (board.isTileOccupied(tile.x, tile.y - 1))
                        {
                            std::cout << "Tile occupied above: (" << tile.x << ", " << tile.y << ")" << std::endl;
                            board.CheckforRow(tile.x, tile.y - 1, placedTilesInfo, -1);

                        }
                        if (board.isTileOccupied(tile.x, tile.y + 1)) {
                            std::cout << "Tile occupied below: (" << tile.x << ", " << tile.y << ")" << std::endl;

                            board.CheckforRow(tile.x, tile.y + 1, placedTilesInfo, 1);
                        }
                    }
                }
                // Check edge tiles on the left and right
                if (board.isTileOccupied(startX - 1, y)) {
                    std::cout << "Edge tile occupied left: (" << startX - 1 << ", " << y << ")" << std::endl;
                    board.CheckforColumn(startX - 1, y, placedTilesInfo, -1);

                }
                if (board.isTileOccupied(endX + 1, y)) {
                    std::cout << "Edge tile occupied right: (" << endX + 1 << ", " << y << ")" << std::endl;
                    board.CheckforColumn(endX + 1, y, placedTilesInfo, 1);
                }
                removeDuplicateTiles(placedTilesInfo);//if by mistake any duplicate tiles exist finish it
            }
            else if (alignment.isSameColumn) {
                std::cout << "Tiles are in the same column" << std::endl;
                std::sort(placedTilesInfo.begin(), placedTilesInfo.end(), [](const TileInfo& a, const TileInfo& b) {
                    return a.y < b.y;
                    });

                // Get the range of y-values to check for occupied tiles
                int x = placedTilesInfo[0].x;
                int startY = placedTilesInfo.front().y;
                int endY = placedTilesInfo.back().y;
                std::cout << "Checking between y = " << startY + 1 << " and y = " << endY << " at x = " << x << std::endl;

                // Traverse between the placed tiles in the same column
                for (int y = startY + 1; y < endY; ++y) {
                    if (board.isTileOccupied(x, y) && !isTilePlacedAt(placedTilesInfo, x, y)) {
                        std::cout << "Tile occupied at: (" << x << ", " << y << ")" << std::endl;
                        TileInfo existingTile(x, y);
                        existingTile.x = x;
                        existingTile.y = y;
                        existingTile = board.getinfo(x, y, existingTile);
                        placedTilesInfo.push_back(existingTile);
                    }
                }

                // Check neighboring tiles
                for (const auto& tile : movetiles) {
                    if (!board.isTileOccupied(tile.x, tile.y)) {
                        if (board.isTileOccupied(tile.x - 1, tile.y)) {
                            std::cout << "Tile occupied left: (" << tile.x - 1 << ", " << tile.y << ")" << std::endl;

                            board.CheckforRow(tile.x - 1, tile.y, placedTilesInfo, -1);
                        }
                        if (board.isTileOccupied(tile.x + 1, tile.y)) {
                            std::cout << "Tile occupied right: (" << tile.x + 1 << ", " << tile.y << ")" << std::endl;

                            board.CheckforRow(tile.x + 1, tile.y, placedTilesInfo, 1);
                        }
                    }
                }
                for (const auto& tile : movetiles) {
                    if (!board.isTileOccupied(tile.x, tile.y)) {
                        if (board.isTileOccupied(tile.x - 1, tile.y)) {
                            std::cout << "Tile occupied left: (" << tile.x - 1 << ", " << tile.y << ")" << std::endl;

                            board.CheckforColumn(tile.x - 1, tile.y, placedTilesInfo, -1);
                        }
                        if (board.isTileOccupied(tile.x + 1, tile.y)) {
                            std::cout << "Tile occupied right: (" << tile.x + 1 << ", " << tile.y << ")" << std::endl;

                            board.CheckforColumn(tile.x + 1, tile.y, placedTilesInfo, 1);
                        }
                    }
                }

                // Check edge tiles on the top and bottom
                if (board.isTileOccupied(x, startY - 1)) {
                    std::cout << "Edge tile occupied above: (" << x << ", " << startY - 1 << ")" << std::endl;
                    board.CheckforRow(x, startY - 1, placedTilesInfo, -1);
                }
                if (board.isTileOccupied(x, endY + 1)) {
                    std::cout << "Edge tile occupied below: (" << x << ", " << endY + 1 << ")" << std::endl;
                    board.CheckforRow(x, endY + 1, placedTilesInfo, 1);
                }
                removeDuplicateTiles(placedTilesInfo);
            }
        }
    }

    std::vector<std::string> Words(const std::vector<TileInfo>& tiles, const std::vector<TileInfo>& movetiles) {
        // Maps to group tiles by row (y-coordinate) and column (x-coordinate)
        std::map<int, std::vector<TileInfo>> rows;    // Group by y (row)
        std::map<int, std::vector<TileInfo>> columns; // Group by x (column)

        // Group tiles by row and column
        for (const auto& tile : tiles) {
            rows[tile.y].push_back(tile);    // Group tiles by y (row)
            columns[tile.x].push_back(tile); // Group tiles by x (column)
        }

        // Function to check if a tile group overlaps with movetiles
        auto hasOverlapWithMovetiles = [&](const std::vector<TileInfo>& tileGroup) {
            for (const auto& tile : tileGroup) {
                for (const auto& movetile : movetiles) {
                    if (tile.x == movetile.x && tile.y == movetile.y) {
                        return true;  // Overlap found
                    }
                }
            }
            return false;  // No overlap
            };

        // Function to generate the word from sorted tiles in a row or column
        auto generateWord = [](std::vector<TileInfo>& tileGroup) {
            // Sort tiles by x or y depending on the group type
            std::sort(tileGroup.begin(), tileGroup.end(), [](const TileInfo& a, const TileInfo& b) {
                if (a.y == b.y) return a.x < b.x; // Sort by x for rows
                return a.y < b.y;                // Sort by y for columns
                });

            // Build the word from sorted tiles
            std::string word;
            for (const auto& tile : tileGroup) {
                word += tile.letter;  // Append the letter to the word
            }
            return word;
            };

        // Vector to store the words formed
        std::vector<std::string> formedWords;

        // Process rows (only if more than 1 tile in that row and overlaps with movetiles)
        for (auto& row : rows) {
            if (row.second.size() > 1 && hasOverlapWithMovetiles(row.second)) {
                formedWords.push_back(generateWord(row.second));
            }
        }

        // Process columns (only if more than 1 tile in that column and overlaps with movetiles)
        for (auto& col : columns) {
            if (col.second.size() > 1 && hasOverlapWithMovetiles(col.second)) {
                formedWords.push_back(generateWord(col.second));
            }
        }

        return formedWords; // Return all words formed
    }



    void displayTiles(const std::vector<TileInfo>& placedTilesInfo) {
        for (const auto& tile : placedTilesInfo) {
            std::cout << "Tile: " << tile.letter << " at (" << tile.x << ", " << tile.y << ") and type:" << tile.type;
        }
    }

};


class Game {
private:
    Valid v;
    sf::RenderWindow window;
    Player* currentPlayer;  // Pointer to the current player
    Panel panel;
    Board board;
    Slate topSlate;
    Slate bottomSlate;
    Player player1;
    Player player2;
    std::vector<char> tileBag;
    Trie t;
    Menu menu;
    int consecutiveSkips = 0;    // Track the number of consecutive skips
    Player* lastSkippedPlayer = nullptr;  // Track the last player who skipped

public:
    Game() : window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Scrabble"),
        player1("Player 1", 530, 5),
        player2("Player 2", 770, 5, true),
        menu(player1, player2),
        panel(
            player1,
            player2,
            [&]() { handleSubmit(); },
            [&]() { handleSkip(); },  // No parameters needed
            [&]() { handleSurrender(); },
            [&]() { scan(); }
        )
    {

        tileBag = generateTileBag();
        topSlate = Slate(4, 0, tileBag, &player1, &board);          // Top player slate
        bottomSlate = Slate(4, GRID_SIZE + 1, tileBag, &player2, &board); // Bottom player slate

        // Set the initial player turn
        currentPlayer = &player1;
        player1.isTurn = true;
    }
    int calculateScore(const std::vector<TileInfo>& placedTilesInfo) {
        int score = 0;
        bool dw = false, tw = false;
        for (const TileInfo& tile : placedTilesInfo) {
            // Get letter value (assuming you have a function to get the letter score)
            int letterScore = getLetterValue(tile.letter);
            // Handle special cases (e.g., tile type bonuses or board location bonuses)
            if (tile.type == TileType::DOUBLE_LETTER) {
                score += (2 * letterScore); // Double the letter score
            }
            else if (tile.type == TileType::TRIPLE_LETTER) {
                score += (3 * letterScore); // Triple the letter score
            }
            else if (tile.type == TileType::TRIPLE_WORD) {
                tw = true;
                score += letterScore;
            }
            else if (tile.type == TileType::DOUBLE_WORD || tile.type == TileType::CENTRE) {
                dw = true;
                score += letterScore;
            }
            else {
                score += letterScore;
            }
        }
        if (dw) {
            score *= 2;
        }
        if (tw) {
            score *= 3;
        }
        return score;
    }
    int getLetterValue(char letter) {
        switch (letter) {
        case 'A': case 'E': case 'I': case 'O': case 'U': case 'L': case 'N': case 'S': case 'T': case 'R':
            return 1;
        case 'D': case 'G':
            return 2;
        case 'B': case 'C': case 'M': case 'P':
            return 3;
        case 'F': case 'H': case 'V': case 'W': case 'Y':
            return 4;
        case 'K':
            return 5;
        case 'J': case 'X':
            return 8;
        case 'Q': case 'Z':
            return 10;
        default:
            return 0; // Handle edge cases or invalid input
        }
    }

    void showSurrenderScreen(sf::RenderWindow& window, const std::string& winner, int winnerScore, const std::string& loser, int loserScore) {
        sf::RectangleShape background(sf::Vector2f(WINDOW_WIDTH, WINDOW_HEIGHT));
        background.setFillColor(sf::Color(0, 0, 0, 150)); // Semi-transparent black background

        sf::Text winnerText, loserText;
        configureText(winnerText, getGlobalFont(), winner + " Wins!!\nScore: " + std::to_string(winnerScore), 30, sf::Vector2f(WINDOW_WIDTH / 2 - 150, WINDOW_HEIGHT / 2 - 50), sf::Color::Green);
        configureText(loserText, getGlobalFont(), loser + " Lost!!\nScore: " + std::to_string(loserScore), 30, sf::Vector2f(WINDOW_WIDTH / 2 - 150, WINDOW_HEIGHT / 2 + 50), sf::Color::Red);

        sf::Clock clock; // Start the clock to track time
        while (clock.getElapsedTime().asSeconds() < 3) { // Keep the screen visible for 3 seconds
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    window.close();
                    return;
                }
            }

            window.clear(); // Clear window to prevent overlapping
            window.draw(background);
            window.draw(winnerText);
            window.draw(loserText);
            window.display();
        }

        // After 3 seconds, clear the screen completely
        window.clear(sf::Color::White);
        window.display();
        menu.isMenuVisible = true;
    }

    void scan() {
        vector<vector<TileInfo>>moves;
        moves = board.findAllPossibleMoves();
        board.findPossibleMoveSpaces();
    }

    void handleSurrender() {
        // Determine the winner and loser based on who surrendered
        Player* winner = (currentPlayer == &player1) ? &player2 : &player1;
        Player* loser = (currentPlayer == &player1) ? &player1 : &player2;

        // Create a larger window for the surrender screen
        sf::RenderWindow surrenderWindow(sf::VideoMode(600, 300), "Game Over!");

        // Set up the main "GAME OVER" title
        sf::Text titleText;
        titleText.setFont(getGlobalFont());
        titleText.setString("GAME OVER");
        titleText.setCharacterSize(50);
        titleText.setFillColor(sf::Color(255, 223, 0)); // Yellow-golden color
        titleText.setStyle(sf::Text::Bold);
        titleText.setPosition(
            (surrenderWindow.getSize().x - titleText.getGlobalBounds().width) / 2, // Center horizontally
            20 // Near the top
        );

        // Set up the winner and loser text
        sf::Text resultText;
        resultText.setFont(getGlobalFont());
        resultText.setCharacterSize(25);
        resultText.setFillColor(sf::Color::White);

        // Customize the result string
        std::string resultString = winner->name + " wins!!\nScore: " + std::to_string(winner->score) + "\n\n" +
            loser->name + " surrenders!!\nScore: " + std::to_string(loser->score);
        resultText.setString(resultString);

        // Center the result text and move it slightly lower
        float resultTextWidth = resultText.getGlobalBounds().width;
        float resultTextHeight = resultText.getGlobalBounds().height;
        resultText.setPosition(
            (surrenderWindow.getSize().x - resultTextWidth) / 2, // Center horizontally
            (surrenderWindow.getSize().y - resultTextHeight) / 2 + 30 // Center vertically and move slightly lower
        );

        // Game Over screen with a dark red background
        while (surrenderWindow.isOpen()) {
            sf::Event event;
            while (surrenderWindow.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    surrenderWindow.close();
                    menu.isMenuVisible = true; // Show the menu after the surrender screen
                    return;
                }
            }

            surrenderWindow.clear(sf::Color(139, 0, 0)); // Dark red background
            surrenderWindow.draw(titleText);
            surrenderWindow.draw(resultText);
            surrenderWindow.display();
        }

        // After the surrender window closes, show the menu
        menu.isMenuVisible = true;
    }


    void handleSkip() {
        Player& currentPlayer = player1.isTurn ? player1 : player2;
        Player& opponent = player1.isTurn ? player2 : player1;

        // Your skipping logic here
        consecutiveSkips++;
        lastSkippedPlayer = &currentPlayer;

        std::cout << currentPlayer.name << " skipped their turn.\n";

        if (consecutiveSkips >= 3) {
            Player* winner = &opponent;
            std::cout << "Game Over! " << currentPlayer.name << " loses.\n";
            std::cout << "Congratulations! " << winner->name << " wins.\n";
            gameOver(&currentPlayer, winner);
            return;
        }

        // Toggle turn
        currentPlayer.isTurn = false;
        opponent.isTurn = true;
    }


    void handlePlayerAction() {
        consecutiveSkips = 0;    // Reset the counter
        lastSkippedPlayer = nullptr; // Clear the last skipped player
        std::cout << "Action performed, skip counter reset.\n";
    }

    void handleSubmit() {
        std::cout << "Submit button clicked!" << std::endl;
        int score = 0;
        std::vector<TileInfo> placedTilesInfo;
        std::vector<TileInfo> movetiles;
        // Collect placed tile information from the appropriate slate
        if (player1.isTurn) {
            placedTilesInfo = topSlate.collectPlacedTileInfo();
        }
        else if (player2.isTurn) {
            placedTilesInfo = bottomSlate.collectPlacedTileInfo();
        }

        // Check if tiles are aligned in a row or column
        AlignmentInfo alignment = v.rowColumnCheck(placedTilesInfo);

        // If placement is invalid, return immediately
        if (!placementchecks(alignment, placedTilesInfo)) {
            return;
        }

        std::cout << "Before Move: ";
        for (const auto& tile : placedTilesInfo) {
            std::cout << "(" << tile.x << ", " << tile.y << ") ";
        }
        std::cout << std::endl;
        movetiles = placedTilesInfo;
        // Make the move
        v.Move(placedTilesInfo, board, movetiles);

        std::cout << "After Move: ";
        for (const auto& tile : placedTilesInfo) {
            std::cout << "(" << tile.x << ", " << tile.y << ") ";
        }
        std::cout << std::endl;

        std::vector<std::string> formedWords = v.Words(placedTilesInfo, movetiles);
        for (string word : formedWords) {
            if (!t.isValidWord(word))
            {
                string m = "                             " + word + " is not a valid word!!";
                showErrorDialog(m, window);
                return;
            }
        }
        // Calculate the score based on the formed word
        score = calculateScore(placedTilesInfo);
        std::cout << "Score: " << score << std::endl;
        panel.updatePlayerScore(*currentPlayer, score);

        // Refill tiles for the current player
        if (player1.isTurn) {
            topSlate.refillTiles(tileBag);
        }
        else if (player2.isTurn) {
            bottomSlate.refillTiles(tileBag);
        }

        // Update the tile count based on the new size of the tileBag
        panel.updateTileCount(tileBag.size());

        handlePlayerAction(); // Reset the skip counter and last skipped player

        // After handling submission, switch turns
        switchTurn();

        // Clear the vector to prepare for the next round
        if (player1.isTurn) {
            topSlate.clearPlacedTiles(placedTilesInfo);
        }
        else if (player2.isTurn) {
            bottomSlate.clearPlacedTiles(placedTilesInfo);
        }
        if (isFirstMove) {
            isFirstMove = false;
        }
    }


    bool placementchecks(AlignmentInfo alignment, std::vector<TileInfo> placedTilesInfo) {
        // Check if there are tiles placed
        if (v.emptycheck(placedTilesInfo)) {
            showErrorDialog("\t\t\t\t\t\tNo tiles have been placed", window);
            return false;
        }

        // First move specific checks
        if (isFirstMove) {
            // Check if (7, 7) is included in placedTilesInfo
            bool centerTilePlaced = false;
            for (const auto& tile : placedTilesInfo) {
                if (tile.x == 7 && tile.y == 7) {
                    centerTilePlaced = true;
                    break;
                }
            }
            if (!centerTilePlaced) {
                showErrorDialog("\t\t\t\t\tGame should start from the center", window);
                return false;
            }
        }

        // Ensure tiles are aligned in the same row or column
        if (!(alignment.isSameRow || alignment.isSameColumn)) {
            showErrorDialog("Please place the tiles in the same row or column", window);
            std::cout << "Invalid placement.\n";
            return false;
        }

        // Check for gaps based on alignment (Gap method should handle alignment check internally)
        if (!v.Gap(placedTilesInfo, board, window)) {
            showErrorDialog("\t\t\t\tGaps detected between placed tiles", window);
            return false;
        }

        // If it�s not the first move, check connectivity to existing tiles
        if (!isFirstMove && !v.isConnectedToExistingTiles(placedTilesInfo, board)) {
            showErrorDialog("Invalid placement:\ntiles are not connected to existing tiles", window);
            std::cout << "Invalid placement: tiles are not connected to existing tiles.\n";
            return false;
        }

        // All checks passed

        return true;
    }


    void switchTurn() {
        if (currentPlayer == &player1) {
            currentPlayer = &player2;
            player1.isTurn = false;
            player2.isTurn = true;
        }
        else {
            currentPlayer = &player1;
            player2.isTurn = false;
            player1.isTurn = true;
        }

        std::cout << currentPlayer->name << "'s turn now!" << std::endl;
    }

    void gameOver(Player* loser, Player* winner) {
        std::cout << "Game Over! " << loser->name << " loses.\n";
        std::cout << "Congratulations! " << winner->name << " wins.\n";

        // Create a larger window for the Game Over screen
        sf::RenderWindow gameOverWindow(sf::VideoMode(600, 300), "Game Over!");

        // Set up the main "GAME OVER" title
        sf::Text titleText;
        titleText.setFont(getGlobalFont());
        titleText.setString("GAME OVER");
        titleText.setCharacterSize(50);
        titleText.setFillColor(sf::Color(255, 223, 0)); // Yellow-golden color
        titleText.setStyle(sf::Text::Bold);
        titleText.setPosition(
            (gameOverWindow.getSize().x - titleText.getGlobalBounds().width) / 2, // Center horizontally
            20 // Near the top
        );

        // Set up the winner and loser text
        sf::Text resultText;
        resultText.setFont(getGlobalFont());
        resultText.setCharacterSize(25);
        resultText.setFillColor(sf::Color::White);

        // Customize the result string
        std::string resultString = winner->name + " wins!!\nScore: " + std::to_string(winner->score) + "\n\n" +
            loser->name + " loses!!\nScore: " + std::to_string(loser->score);
        resultText.setString(resultString);

        // Center the result text and move it slightly lower
        float resultTextWidth = resultText.getGlobalBounds().width;
        float resultTextHeight = resultText.getGlobalBounds().height;
        resultText.setPosition(
            (gameOverWindow.getSize().x - resultTextWidth) / 2, // Center horizontally
            (gameOverWindow.getSize().y - resultTextHeight) / 2 + 30 // Center vertically and move slightly lower
        );

        // Game Over screen with a dark red background
        while (gameOverWindow.isOpen()) {
            sf::Event event;
            while (gameOverWindow.pollEvent(event)) {
                if (event.type == sf::Event::Closed) {
                    gameOverWindow.close();
                    exit(0);
                }
            }

            gameOverWindow.clear(sf::Color(139, 0, 0)); // Dark red background
            gameOverWindow.draw(titleText);
            gameOverWindow.draw(resultText);
            gameOverWindow.display();
        }
    }

    void run() {
        std::string word = " ";
        int row = 0, col = 0;
        bool horizontal = false;


        while (window.isOpen()) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();


                if (event.type == sf::Event::MouseButtonPressed) {
                    if (event.mouseButton.button == sf::Mouse::Left) {
                        if (menu.isVisible()) {
                            menu.handleMouseButtonPressed();
                        }
                        else {
                            topSlate.handleMousePress(sf::Vector2f(event.mouseButton.x, event.mouseButton.y));
                            bottomSlate.handleMousePress(sf::Vector2f(event.mouseButton.x, event.mouseButton.y));
                            panel.handleMouseButtonPressed();
                            sf::Vector2f mousePos(event.mouseButton.x, event.mouseButton.y);
                            printMouseCoordinates(mousePos);  // Print the coordinates
                        }
                    }
                }

                if (event.type == sf::Event::MouseButtonReleased) {
                    if (event.mouseButton.button == sf::Mouse::Left) {
                        if (menu.isVisible()) {
                            menu.handleMouseButtonReleased();
                        }
                        else {
                            topSlate.handleMouseRelease(sf::Vector2f(event.mouseButton.x, event.mouseButton.y), window);
                            bottomSlate.handleMouseRelease(sf::Vector2f(event.mouseButton.x, event.mouseButton.y), window);
                            panel.handleMouseButtonReleased();
                        }
                    }
                }

                if (event.type == sf::Event::MouseMoved) {
                    if (menu.isVisible()) {
                        menu.update(sf::Vector2f(event.mouseMove.x, event.mouseMove.y));
                    }
                    else {
                        topSlate.handleMouseMove(sf::Vector2f(event.mouseMove.x, event.mouseMove.y));
                        bottomSlate.handleMouseMove(sf::Vector2f(event.mouseMove.x, event.mouseMove.y));
                        panel.update(sf::Vector2f(event.mouseMove.x, event.mouseMove.y));
                    }
                }
            }


            window.clear(sf::Color::White);
            if (menu.isVisible()) {
                menu.draw(window);
            }
            else {
                board.draw(window);
                topSlate.draw(window);
                bottomSlate.draw(window);
                panel.draw(window);
                player1.draw(window);
                player2.draw(window);


            }

            window.display();
        }
    }


};

int main() {
    // Create a window to display the loading screen
    sf::RenderWindow window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Scrabble");

    // Load font
    sf::Font font;
    if (!font.loadFromFile("C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/font.otf")) {
        std::cerr << "Error: Could not load font." << std::endl;
        return -1;
    }

    // Show loading screen while loading resources
    showLoadingScreen(window, font, "C:/Users/hp/OneDrive/Documents/UNI doc/DSA/test project/alphabets.jpeg");


    // Load heavy resources here (e.g., dictionary, textures, etc.)
    Trie dictionaryTrie;
    dictionaryTrie = Trie(); // Assuming this loads the dictionary

    // Now create and run the game
    Game game;
    window.clear();
    game.run();

    return 0;
}